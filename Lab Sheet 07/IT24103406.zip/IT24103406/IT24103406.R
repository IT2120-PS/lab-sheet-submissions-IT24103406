setwd("C:\\Users\\ddhan\\OneDrive\\Desktop\\IT24103406")

# Q1
a <- 0   
b <- 40 
p <- (25 - 10) / (b - a)
p

# Q2
lambda <- 1/3
p <- pexp(2, rate=lambda)
p

#Q3(i)
p <- 1 - pnorm(130, mean=100, sd=15)
p

#Q3(ii)
q <- qnorm(0.95, mean=100, sd=15)
q
